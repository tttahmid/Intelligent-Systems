import numpy as np
from sklearn.model_selection import train_test_split

def load_multi_digit_dataset():
    # Adjust paths as needed
    images = np.load("data/multi_digits/combined.npy")
    labels = np.load("data/multi_digits/segmented.npy")

    print("Images shape:", images.shape)
    print("Labels shape:", labels.shape)

    # Normalize pixel values (0–255 → 0–1)
    images = images.astype("float32") / 255.0

    # Split into train/test sets
    X_train, X_test, y_train, y_test = train_test_split(
        images, labels, test_size=0.2, random_state=42
    )
    return X_train, X_test, y_train, y_test
